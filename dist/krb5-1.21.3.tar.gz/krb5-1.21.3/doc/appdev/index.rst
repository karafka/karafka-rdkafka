For application developers
==========================

.. toctree::
   :maxdepth: 1

   gssapi.rst
   y2038.rst
   h5l_mit_apidiff.rst
   init_creds.rst
   princ_handle.rst

.. toctree::
   :maxdepth: 1

   refs/index.rst
