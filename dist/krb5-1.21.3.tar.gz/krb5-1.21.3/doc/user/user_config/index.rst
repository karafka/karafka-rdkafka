User config files
=================

The following files in your home directory can be used to control the
behavior of Kerberos as it applies to your account (unless they have
been disabled by your host's configuration):

.. toctree::
   :maxdepth: 1

   kerberos.rst
   k5login.rst
   k5identity.rst
