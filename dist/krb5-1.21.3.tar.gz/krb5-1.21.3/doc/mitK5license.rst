.. _mitK5license:

MIT Kerberos License information
================================

.. toctree::
    :hidden:

    copyright.rst

.. include::  notice.rst
