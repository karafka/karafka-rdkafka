Protocols and file formats
==========================

.. toctree::
   :maxdepth: 1

   ccache_file_format
   keytab_file_format
   rcache_file_format
   cookie
   freshness_token
