#!/bin/bash
set -e
source /home/user/venv/bin/activate
make style-check
